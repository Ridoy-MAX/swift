# Responsive Dropdown Menu
## [Watch it on youtube](https://youtu.be/_cUM13VUw8U)
### Responsive Dropdown Menu
Beautiful and clean responsive navigation bar includes a beautiful drop-down side menu in the mobile version that contains a profile image, personal data, drop-down links, and in the desktop version a sticky header with all the above elements.

Don't forget to join the channel for more videos like this.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
